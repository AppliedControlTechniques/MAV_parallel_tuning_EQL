/*
 * update_parameters_EQL_parallel_avg_terminate.h
 *
 * Code generation for function 'update_parameters_EQL_parallel_avg_terminate'
 *
 */

#ifndef __UPDATE_PARAMETERS_EQL_PARALLEL_AVG_TERMINATE_H__
#define __UPDATE_PARAMETERS_EQL_PARALLEL_AVG_TERMINATE_H__

/* Include files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rtwtypes.h"
#include "update_parameters_EQL_parallel_avg_types.h"

/* Function Declarations */
#ifdef __cplusplus

extern "C" {

#endif

  extern void update_parameters_EQL_parallel_avg_terminate(void);

#ifdef __cplusplus

}
#endif
#endif

/* End of code generation (update_parameters_EQL_parallel_avg_terminate.h) */
