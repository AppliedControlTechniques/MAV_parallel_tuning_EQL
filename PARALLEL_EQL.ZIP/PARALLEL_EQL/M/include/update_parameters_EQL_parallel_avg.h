/*
 * update_parameters_EQL_parallel_avg.h
 *
 * Code generation for function 'update_parameters_EQL_parallel_avg'
 *
 */

#ifndef __UPDATE_PARAMETERS_EQL_PARALLEL_AVG_H__
#define __UPDATE_PARAMETERS_EQL_PARALLEL_AVG_H__

/* Include files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rtwtypes.h"
#include "update_parameters_EQL_parallel_avg_types.h"

/* Function Declarations */
#ifdef __cplusplus

extern "C" {

#endif

  extern void update_parameters_EQL_parallel_avg(const double input[2], double
    main_iteration_counter, const double P1_range[2], const double P2_range[2],
    double Par_initial, double output[5]);

#ifdef __cplusplus

}
#endif
#endif

/* End of code generation (update_parameters_EQL_parallel_avg.h) */
