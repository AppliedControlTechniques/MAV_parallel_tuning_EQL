/*
 * update_parameters_EQL_parallel_avg_data.h
 *
 * Code generation for function 'update_parameters_EQL_parallel_avg_data'
 *
 */

#ifndef __UPDATE_PARAMETERS_EQL_PARALLEL_AVG_DATA_H__
#define __UPDATE_PARAMETERS_EQL_PARALLEL_AVG_DATA_H__

/* Include files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rtwtypes.h"
#include "update_parameters_EQL_parallel_avg_types.h"

/* Variable Declarations */
extern double information_matrix[399];
extern double changed_parameter;

#endif

/* End of code generation (update_parameters_EQL_parallel_avg_data.h) */
