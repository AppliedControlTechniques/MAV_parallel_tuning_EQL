/*
 * update_parameters_EQL_parallel_avg_types.h
 *
 * Code generation for function 'update_parameters_EQL_parallel_avg'
 *
 */

#ifndef __UPDATE_PARAMETERS_EQL_PARALLEL_AVG_TYPES_H__
#define __UPDATE_PARAMETERS_EQL_PARALLEL_AVG_TYPES_H__

/* Include files */
#include "rtwtypes.h"

/* Type Definitions */
#include <stdio.h>

#endif
/* End of code generation (update_parameters_EQL_parallel_avg_types.h) */
