﻿// THIS FILE IS FOR MASTER

// some ros includes
#include <ros/package.h>
#include <ros/ros.h>

// some std includes
#include <stdio.h>
#include <stdlib.h>

#include <nav_msgs/Odometry.h>
#include <std_msgs/Bool.h>
#include <std_msgs/Float32.h>
#include <std_msgs/Int32.h>
// include messages need to control the flight of the MAV
#include <mrs_msgs/TrackerTrajectory.h>
#include <mrs_msgs/PositionCommand.h>
// include messages for services
#include <std_srvs/Trigger.h>

#include <mutex>
#include <thread>

// this is neccessary to change gains
#include <dynamic_reconfigure/Config.h>
#include <dynamic_reconfigure/Reconfigure.h>
#include <dynamic_reconfigure/ReconfigureRequest.h>

#include "update_parameters_EQL_parallel_avg.h"

#define SLEEP_DURATION 200

// subscribers
ros::Subscriber sub_UAV2_state;
ros::Subscriber sub_UAV2_gains_changed;
ros::Subscriber sub_UAV2_perf_collected;
// publishers
ros::Publisher pub_trajectory;
ros::Publisher pub_UAV1_gain1;
ros::Publisher pub_UAV1_gain2;
ros::Publisher pub_UAV2_gain1;
ros::Publisher pub_UAV2_gain2;
ros::Publisher pub_start;

// data from outside
bool               uav2_gains_changed     = false;
bool               next_iteration_started = false;
// parameters from config files
int    main_loop_rate;
int    thread_rate;
int    loop_count;

////////////////////////////////////////////////////////////////////////


double use_filtered = 1;

double prior_filtered_control_error = 0;    // used when filtered error is passed to the function
double prior_control_error          = 0.1;  // used as above, initially non-zero to obtain non-zero filt'd error
double aux_variable;
double main_iteration_counter = 0;

double output_EQL_parallel[5];

double Par_initial = 0.2;  // TODO: the value should be set
// states of the state machine
typedef enum {
  IDLE     = 0,  // keeping constant altitude, fixed gains
  FLYING   = 1,  // change gains, and after that gather performance index
  OPTIMIZE = 2,  // perform single optimization step, afterwards - move to FLYING state
} state_gains;

double P1_range[2];
double P2_range[2];

double J_UAV[2];  //[2];

// J_UAV[0] = 0;
// J_UAV[1] = 0;

bool UAV1_perf_collected;  // informs if UAV1 collected perf index successfully
bool UAV2_perf_collected;  // informs if UAV2 collected perf index successfully
bool start_next_iteration = false;


// P1_range[0] = 4;
// P1_range[1] = 12;

// P2_range[0] = 2;
// P2_range[1] = 7;

// UAV1_perf_collected = false;
// UAV2_perf_collected = false;

double UAV1_gain1;
double UAV1_gain2;

double UAV2_gain1;
double UAV2_gain2;

double UAV1_perf;  // performance index for UAV1
double UAV2_perf;  // performance index obtained from UAV2
double start_x, start_y;


double UAV_tuning_finished;  // informs if tuning has finished

state_gains current_state = IDLE;
state_gains past_state    = IDLE;
state_gains uav2_state    = IDLE;

double control_error;

// just count how many times the thread has looped
int looped = 0;

// the trajectory primitive
std::vector<double> trajectory_primitive_x;
std::vector<double> trajectory_primitive_y;
std::vector<double> trajectory_primitive_z;

// variable that hold the default gains
Gains_t            default_gains;
Gains_t            modified_gains_UAV1;
ros::ServiceClient set_gains_client;

void init_variables() {
  J_UAV[0]            = 0;
  J_UAV[1]            = 0;
  P1_range[0]         = 0;
  P1_range[1]         = 1;
  P2_range[0]         = 0;
  P2_range[1]         = 1;
  UAV1_perf_collected = false;
  UAV2_perf_collected = false;
  UAV1_perf           = 0;  // initial values put to zero by default
  UAV2_perf           = 0;
  UAV_tuning_finished = 0;  // initially logical zero
}


void nextIterationStartedCallback(const std_msgs::Bool& msg) {
  next_iteration_started = msg.data;
}

void uav2ChangeGainsCallback(const std_msgs::Bool& msg) {
  uav2_gains_changed = msg.data;
}

void uav2PerfCallback(const std_msgs::Float32& msg) {
  UAV2_perf_collected = true;
  UAV2_perf           = msg.data;
  //ROS_INFO("UAV2 performance collected received");
}


// method for changing state
void changeState(state_gains new_state) {

  past_state    = current_state;
  current_state = new_state;

  // make actions when changing to some states
  switch (new_state) {

    case IDLE:
      // do nothing, simply hover

      //ROS_INFO("Changing to IDLE state");

      break;

    case FLYING:
      {
      // publish trajectory and gather performance index

      looped = 0;

      setGains(modified_gains_UAV1);
      ros::Duration wait(1.0);
      wait.sleep();
      publishPrimitiveTrajectory();

      // TODO:
      // UAV2 should be started too info its FLYING mode!!!

      }
      break;

    case OPTIMIZE:
      {

      // perform single optimization step in the main drone (UAV1)

      looped = 0;
      //ROS_WARN("Changing to OPTIMIZE state");

      }
      break;
  }
}

bool startServiceCallback(std_srvs::Trigger::Request& req, std_srvs::Trigger::Response& res) {

  start_x = setpoint_.position.x;
  start_y = setpoint_.position.y;
  std_msgs::Float32 float_message;

  J_UAV[0] = 0;  // dummy - first call of the method does not require that, it only modifies gains!
  J_UAV[1] = 0;  // dummy - first call of the method does not require that, it only modifies gains!

  changeState(FLYING);
  res.success = true;
  res.message = "Switching to FLYING state -- main callback call";

  if (use_filtered) {
    //ROS_INFO("The metod will use the low-pass filtered error signal");
  }
  return true;
}

void mainThread(void) {

  ros::Rate r(thread_rate);

  // infinitely run a state machine
  while (ros::ok()) {

    // this makes the thread run with the set rate
    r.sleep();

    if (!got_odometry || !got_setpoint || !got_error) {

      ROS_WARN_THROTTLE(1, "Missing some data...");
      continue;
    }

    ROS_INFO_ONCE("The thread has started...");

    std_msgs::Float32 float_message;

    switch (current_state) {

      case IDLE:
        // IDLE: drone hovers
        // drone awaits for flags indicating successfull collection of performance indices

        if (UAV1_perf_collected && UAV2_perf_collected) {
          // jump to OPTIMIZE state -- performance indices have been collected by both UAVs
          changeState(OPTIMIZE);
          //ROS_INFO("Change state to OPTIMIZE");
        }

        break;

      case FLYING:
        {
        // FLYING: drone track a single reference primitive
        // drone awaits for flags indicating successfull collection of performance indices

        // increment performance index of UAV1 (absolute value of tracking error)
        UAV1_perf += fabs(control_error);
        // increment the loop counter
        looped++;

        if ((unsigned long)looped == loop_count * trajectory_primitive_z.size()) {
          // if the reference primitive is finished, jump to idle state
          // to wait for UAV2 to return its performance indices

          UAV1_perf_collected = true;  // UAV1 has collected its performance index

          changeState(IDLE);
        }

        }
        break;

      case OPTIMIZE:
        {
        UAV1_perf_collected = false;  // setting up flags - no performance indexes
        UAV2_perf_collected = false;  // are collected (will be useful when
        // returning back to flying state

        J_UAV[0] = UAV1_perf;
        J_UAV[1] = UAV2_perf;

        update_parameters_EQL_parallel_avg(J_UAV, main_iteration_counter, P1_range, P2_range, Par_initial, output_EQL_parallel);
        //ROS_INFO("Parameters_updated");
        UAV1_gain1             = output_EQL_parallel[0];
        UAV1_gain2             = output_EQL_parallel[1];
        UAV2_gain1             = output_EQL_parallel[2];
        UAV2_gain2             = output_EQL_parallel[3];
        main_iteration_counter = output_EQL_parallel[4];

        // its arguments: performance indices
        // its ouput: new gains - UAV1_gain1, UAV1_gain2, UAV2_gain1, UAV2_gain2 and main iteration counter

        if (main_iteration_counter > 99) {
          UAV_tuning_finished = 1;
        }  // TUNING HAS FINISHED!


        if (!UAV_tuning_finished) {  // tuning is still in progress...
          UAV1_perf = 0;             // performance index of UAV1 must be put to zero
          UAV2_perf = 0;             // performance index of UAV2 must be put to zero

          float_message.data = UAV1_gain1;
          pub_UAV1_gain1.publish(float_message);

          float_message.data = UAV1_gain2;
          pub_UAV1_gain2.publish(float_message);

          float_message.data = UAV2_gain1;
          pub_UAV2_gain1.publish(float_message);

          float_message.data = UAV2_gain2;
          pub_UAV2_gain2.publish(float_message);

          modified_gains_UAV1.kp_z = UAV1_gain1;
          modified_gains_UAV1.kd_z = UAV1_gain2;
          setGains(modified_gains_UAV1);
          while (!uav2_gains_changed) {
            float_message.data = UAV2_gain1;
            pub_UAV2_gain1.publish(float_message);
            float_message.data = UAV2_gain2;
            pub_UAV2_gain2.publish(float_message);
            //ROS_INFO("SLeeping");
            ros::Duration(0.5).sleep();
            //ROS_INFO("End sleeping");
          }
          //ROS_INFO("Gains on UAV2 changed.");
          uav2_gains_changed   = false;
          start_next_iteration = true;
          next_iteration_started = false;
          while (!next_iteration_started) {  
            ros::Duration(0.5).sleep();
            publishStart();
            //ROS_INFO("Start publishing.");
          }
          start_next_iteration   = false;
          next_iteration_started = false;
          changeState(FLYING);  // publish also the state
        }  // go back to FLYING state to get new performance indices

        else {
          //ROS_WARN("TUNING EXPERIMENT HAS FINISHED!");
          changeState(IDLE);
          // TODO: DONE
          // UAV2 should also be put into IDLE state...
        }  // if tuning has finished - hover, do nothing
        //ROS_INFO("Optimization loop finished");
        }
        break;
    }
  }
}

  // allowable range for parameter no. 1
  nh.param("P1_range_low", P1_range[0], 0.0);
  nh.param("P1_range_high", P1_range[1], 1.0);
  // allowable range for parameter no. 2
  nh.param("P2_range_low", P2_range[0], 0.0);
  nh.param("P2_range_high", P2_range[1], 1.0);

  output_EQL_parallel[0] = 0;
  output_EQL_parallel[1] = 0;
  output_EQL_parallel[2] = 0;
  output_EQL_parallel[3] = 0;
  output_EQL_parallel[4] = 0;

