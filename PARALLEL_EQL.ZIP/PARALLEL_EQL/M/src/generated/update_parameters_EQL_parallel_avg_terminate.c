/*
 * update_parameters_EQL_parallel_avg_terminate.c
 *
 * Code generation for function 'update_parameters_EQL_parallel_avg_terminate'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "update_parameters_EQL_parallel_avg.h"
#include "update_parameters_EQL_parallel_avg_terminate.h"
#include <stdio.h>

/* Function Definitions */
void update_parameters_EQL_parallel_avg_terminate(void)
{
  /* (no terminate code required) */
}

/* End of code generation (update_parameters_EQL_parallel_avg_terminate.c) */
