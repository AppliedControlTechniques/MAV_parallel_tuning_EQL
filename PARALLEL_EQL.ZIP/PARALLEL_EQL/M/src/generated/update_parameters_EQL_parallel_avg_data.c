/*
 * update_parameters_EQL_parallel_avg_data.c
 *
 * Code generation for function 'update_parameters_EQL_parallel_avg_data'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "update_parameters_EQL_parallel_avg.h"
#include "update_parameters_EQL_parallel_avg_data.h"
#include <stdio.h>

/* Variable Definitions */
double information_matrix[399];
double changed_parameter;

/* End of code generation (update_parameters_EQL_parallel_avg_data.c) */
