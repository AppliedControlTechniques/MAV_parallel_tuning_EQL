/*
 * update_parameters_EQL_parallel_avg_initialize.c
 *
 * Code generation for function 'update_parameters_EQL_parallel_avg_initialize'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "update_parameters_EQL_parallel_avg.h"
#include "update_parameters_EQL_parallel_avg_initialize.h"
#include "update_parameters_EQL_parallel_avg_data.h"
#include <stdio.h>

/* Named Constants */
#define b_changed_parameter            (1.0)

/* Function Definitions */
void update_parameters_EQL_parallel_avg_initialize(void)
{
  rt_InitInfAndNaN(8U);
  changed_parameter = b_changed_parameter;
  memset(&information_matrix[0], 0, 399U * sizeof(double));
}

/* End of code generation (update_parameters_EQL_parallel_avg_initialize.c) */
