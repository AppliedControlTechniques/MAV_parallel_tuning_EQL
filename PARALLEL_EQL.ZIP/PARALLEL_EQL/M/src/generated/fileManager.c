/*
 * fileManager.c
 *
 * Code generation for function 'fileManager'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "update_parameters_EQL_parallel_avg.h"
#include "fileManager.h"
#include <stdio.h>

/* Function Definitions */
void fileManager(FILE * *f, boolean_T *a)
{
  *f = stdout;
  *a = true;
}

/* End of code generation (fileManager.c) */
