/*
 * fprintf.c
 *
 * Code generation for function 'fprintf'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "update_parameters_EQL_parallel_avg.h"
#include "fprintf.h"
#include "fileManager.h"
#include <stdio.h>

/* Function Definitions */
void b_fprintf(void)
{
  FILE * b_NULL;
  boolean_T autoflush;
  FILE * filestar;
  static const char cfmt[63] = { '\x0a', '*', '*', '*', '*', '*', '*', '*', '*',
    '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*',
    '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*',
    '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*',
    '*', '*', '*', '*', '*', '*', '*', '*', '\x00' };

  b_NULL = NULL;
  fileManager(&filestar, &autoflush);
  if (filestar == b_NULL) {
  } else {
    fprintf(filestar, cfmt);
    fflush(filestar);
  }
}

void c_fprintf(void)
{
  FILE * b_NULL;
  boolean_T autoflush;
  FILE * filestar;
  static const char cfmt[63] = { '\x0a', ' ', '(', 'c', ')', ' ', 'M', 'o', 'd',
    'e', 'l', '-', 'f', 'r', 'e', 'e', ' ', 'a', 'u', 't', 'o', 't', 'u', 'n',
    'e', 'r', ' ', '(', '2', ' ', 'p', 'a', 'r', 'a', 'm', 'e', 't', 'e', 'r',
    's', ')', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',
    ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '\x00' };

  b_NULL = NULL;
  fileManager(&filestar, &autoflush);
  if (filestar == b_NULL) {
  } else {
    fprintf(filestar, cfmt);
    fflush(filestar);
  }
}

void d_fprintf(void)
{
  FILE * b_NULL;
  boolean_T autoflush;
  FILE * filestar;
  static const char cfmt[63] = { '\x0a', ' ', ' ', ' ', ' ', ' ', 'b', 'a', 's',
    'e', 'd', ' ', 'o', 'n', ' ', 'z', 'e', 'r', 'o', '-', 'o', 'r', 'd', 'e',
    'r', ' ', 'e', 'q', 'u', 'a', 'l', '-', 'd', 'i', 'v', 'i', 's', 'i', 'o',
    'n', ' ', 's', 'e', 'a', 'r', 'c', 'h', ' ', 'm', 'e', 't', 'h', 'o', 'd',
    ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '\x00' };

  b_NULL = NULL;
  fileManager(&filestar, &autoflush);
  if (filestar == b_NULL) {
  } else {
    fprintf(filestar, cfmt);
    fflush(filestar);
  }
}

void e_fprintf(void)
{
  FILE * b_NULL;
  boolean_T autoflush;
  FILE * filestar;
  static const char cfmt[63] = { '\x0a', ' ', ' ', ' ', ' ', ' ', 'P', 'A', 'R',
    'A', 'L', 'L', 'E', 'L', ' ', 'V', 'E', 'R', 'S', 'I', 'O', 'N', ' ', '(',
    '2', ' ', 'd', 'r', 'o', 'n', 'e', 's', ',', ' ', 'w', 'i', 't', 'h', ' ',
    'a', 'v', 'e', 'r', 'a', 'g', 'i', 'n', 'g', ')', ' ', ' ', ' ', ' ', ' ',
    ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '\x00' };

  b_NULL = NULL;
  fileManager(&filestar, &autoflush);
  if (filestar == b_NULL) {
  } else {
    fprintf(filestar, cfmt);
    fflush(filestar);
  }
}

void f_fprintf(void)
{
  FILE * b_NULL;
  boolean_T autoflush;
  FILE * filestar;
  static const char cfmt[63] = { '\x0a', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',
    ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',
    ' ', ' ', ' ', ' ', ' ', 'D', 'a', 'r', 'i', 'u', 's', 'z', ' ', 'H', 'o',
    'r', 'l', 'a', ',', ' ', 'W', 'o', 'j', 'c', 'i', 'e', 'c', 'h', ' ', 'G',
    'i', 'e', 'r', 'n', 'a', 'c', 'k', 'i', '\x00' };

  b_NULL = NULL;
  fileManager(&filestar, &autoflush);
  if (filestar == b_NULL) {
  } else {
    fprintf(filestar, cfmt);
    fflush(filestar);
  }
}

void g_fprintf(void)
{
  FILE * b_NULL;
  boolean_T autoflush;
  FILE * filestar;
  static const char cfmt[63] = { '\x0a', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',
    ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',
    ' ', ' ', ' ', ' ', ' ', 'P', 'o', 'z', 'n', 'a', 'n', ' ', 'U', 'n', 'i',
    'v', 'e', 'r', 's', 'i', 't', 'y', ' ', 'o', 'f', ' ', 'T', 'e', 'c', 'h',
    'n', 'o', 'l', 'o', 'g', 'y', ' ', ' ', '\x00' };

  b_NULL = NULL;
  fileManager(&filestar, &autoflush);
  if (filestar == b_NULL) {
  } else {
    fprintf(filestar, cfmt);
    fflush(filestar);
  }
}

void h_fprintf(void)
{
  FILE * b_NULL;
  boolean_T autoflush;
  FILE * filestar;
  static const char cfmt[63] = { '\x0a', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',
    ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',
    ' ', ' ', ' ', ' ', ' ', 'd', 'a', 'r', 'i', 'u', 's', 'z', '.', 'h', 'o',
    'r', 'l', 'a', '@', 'p', 'u', 't', '.', 'p', 'o', 'z', 'n', 'a', 'n', '.',
    'p', 'l', ' ', ' ', ' ', ' ', ' ', ' ', '\x00' };

  b_NULL = NULL;
  fileManager(&filestar, &autoflush);
  if (filestar == b_NULL) {
  } else {
    fprintf(filestar, cfmt);
    fflush(filestar);
  }
}

void i_fprintf(void)
{
  FILE * b_NULL;
  boolean_T autoflush;
  FILE * filestar;
  static const char cfmt[45] = { '\x0a', ' ', 'a', 'c', 'c', 'u', 'r', 'a', 'c',
    'y', ' ', 'o', 'f', ' ', 'c', 'a', 'l', 'c', 'u', 'l', 'a', 't', 'i', 'o',
    'n', 's', ' ', '(', 'e', 'p', 's', 'i', 'l', 'o', 'n', ')', ' ', '=', ' ',
    '0', '.', '1', '2', '5', '\x00' };

  b_NULL = NULL;
  fileManager(&filestar, &autoflush);
  if (filestar == b_NULL) {
  } else {
    fprintf(filestar, cfmt);
    fflush(filestar);
  }
}

void j_fprintf(void)
{
  FILE * b_NULL;
  boolean_T autoflush;
  FILE * filestar;
  static const char cfmt[41] = { '\x0a', ' ', 'n', 'o', '.', ' ', 'o', 'f', ' ',
    'b', 'o', 'o', 't', 's', 't', 'r', 'a', 'p', ' ', 'c', 'y', 'c', 'l', 'e',
    's', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '=', ' ',
    '2', '\x00' };

  b_NULL = NULL;
  fileManager(&filestar, &autoflush);
  if (filestar == b_NULL) {
  } else {
    fprintf(filestar, cfmt);
    fflush(filestar);
  }
}

void k_fprintf(void)
{
  FILE * b_NULL;
  boolean_T autoflush;
  FILE * filestar;
  static const char cfmt[63] = { '\x0a', ' ', 't', 'o', 't', 'a', 'l', ' ', 'n',
    'u', 'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ', 'm', 'a', 'i', 'n', ' ', 'i',
    't', 'e', 'r', 'a', 't', 'i', 'o', 'n', 's', ' ', ' ', ' ', ' ', '=', ' ',
    '5', '6', ' ', '(', '2', '8', ' ', 'p', 'a', 'r', 'a', 'l', 'l', 'e', 'l',
    ' ', 'i', 't', 'e', 'r', 's', '.', ')', '\x00' };

  b_NULL = NULL;
  fileManager(&filestar, &autoflush);
  if (filestar == b_NULL) {
  } else {
    fprintf(filestar, cfmt);
    fflush(filestar);
  }
}

void l_fprintf(void)
{
  FILE * b_NULL;
  boolean_T autoflush;
  FILE * filestar;
  static const char cfmt[3] = { '\x0a', '\x0a', '\x00' };

  b_NULL = NULL;
  fileManager(&filestar, &autoflush);
  if (filestar == b_NULL) {
  } else {
    fprintf(filestar, cfmt);
    fflush(filestar);
  }
}

void m_fprintf(void)
{
  FILE * b_NULL;
  boolean_T autoflush;
  FILE * filestar;
  static const char cfmt[79] = { 'I', 't', 'e', 'r', '.', ' ', ' ', ' ', 'P',
    'a', 'r', ' ', ' ', '|', ' ', ' ', ' ', ' ', ' ', ' ', 'P', 'a', 'r', '(',
    '-', ')', ' ', ' ', ' ', ' ', ' ', ' ', 'P', 'a', 'r', '(', '+', ')', ' ',
    '|', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', 'P', 'a', 'r', '1', ' ', ' ',
    ' ', ' ', ' ', ' ', ' ', ' ', 'P', 'a', 'r', '2', ' ', '|', ' ', ' ', ' ',
    ' ', ' ', ' ', 'J', ' ', ' ', ' ', ' ', ' ', '\x00' };

  b_NULL = NULL;
  fileManager(&filestar, &autoflush);
  if (filestar == b_NULL) {
  } else {
    fprintf(filestar, cfmt);
    fflush(filestar);
  }
}

void n_fprintf(void)
{
  FILE * b_NULL;
  boolean_T autoflush;
  FILE * filestar;
  static const char cfmt[81] = { '\x0a', '-', '-', '-', '-', '-', '-', '-', '-',
    '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-',
    '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-',
    '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-',
    '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-',
    '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '\x00' };

  b_NULL = NULL;
  fileManager(&filestar, &autoflush);
  if (filestar == b_NULL) {
  } else {
    fprintf(filestar, cfmt);
    fflush(filestar);
  }
}

void o_fprintf(double varargin_1)
{
  FILE * b_NULL;
  boolean_T autoflush;
  FILE * filestar;
  static const char cfmt[7] = { '\x0a', '%', '5', '.', '0', 'f', '\x00' };

  b_NULL = NULL;
  fileManager(&filestar, &autoflush);
  if (filestar == b_NULL) {
  } else {
    fprintf(filestar, cfmt, varargin_1);
    fflush(filestar);
  }
}

void p_fprintf(double varargin_1)
{
  FILE * b_NULL;
  boolean_T autoflush;
  FILE * filestar;
  static const char cfmt[8] = { ' ', ' ', '%', '5', '.', '0', 'f', '\x00' };

  b_NULL = NULL;
  fileManager(&filestar, &autoflush);
  if (filestar == b_NULL) {
  } else {
    fprintf(filestar, cfmt, varargin_1);
    fflush(filestar);
  }
}

void q_fprintf(double varargin_1)
{
  FILE * b_NULL;
  boolean_T autoflush;
  FILE * filestar;
  static const char cfmt[11] = { ' ', '|', ' ', ' ', '%', '1', '0', '.', '4',
    'f', '\x00' };

  b_NULL = NULL;
  fileManager(&filestar, &autoflush);
  if (filestar == b_NULL) {
  } else {
    fprintf(filestar, cfmt, varargin_1);
    fflush(filestar);
  }
}

void r_fprintf(double varargin_1)
{
  FILE * b_NULL;
  boolean_T autoflush;
  FILE * filestar;
  static const char cfmt[9] = { ' ', ' ', '%', '1', '0', '.', '4', 'f', '\x00' };

  b_NULL = NULL;
  fileManager(&filestar, &autoflush);
  if (filestar == b_NULL) {
  } else {
    fprintf(filestar, cfmt, varargin_1);
    fflush(filestar);
  }
}

void s_fprintf(void)
{
  FILE * b_NULL;
  boolean_T autoflush;
  FILE * filestar;
  static const char cfmt[88] = { '\x0a', '>', '>', ' ', 'T', 'h', 'e', ' ', 'a',
    'l', 'g', 'o', 'r', 'i', 't', 'h', 'm', ' ', 'r', 'e', 'a', 'c', 'h', 'e',
    'd', ' ', 'i', 't', 's', ' ', 'e', 'x', 'p', 'e', 'c', 't', 'e', 'd', ' ',
    'n', 'u', 'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ', 'i', 't', 'e', 'r', 'a',
    't', 'i', 'o', 'n', 's', ' ', '(', '2', ' ', 'b', 'o', 'o', 't', 's', 't',
    'r', 'a', 'p', 's', ')', ',', ' ', 't', 'e', 'r', 'm', 'i', 'n', 'a', 't',
    'i', 'n', 'g', '\x00' };

  b_NULL = NULL;
  fileManager(&filestar, &autoflush);
  if (filestar == b_NULL) {
  } else {
    fprintf(filestar, cfmt);
    fflush(filestar);
  }
}

void t_fprintf(void)
{
  FILE * b_NULL;
  boolean_T autoflush;
  FILE * filestar;
  static const char cfmt[58] = { '\x0a', '>', '>', ' ', 'O', 'P', 'T', 'I', 'M',
    'A', 'L', ' ', 'S', 'O', 'L', 'U', 'T', 'I', 'O', 'N', ' ', '(', 'P', 'a',
    'r', '1', ',', 'P', 'a', 'r', '2', ')', ' ', 'w', '.', 'r', '.', 't', '.',
    ' ', 'g', 'i', 'v', 'e', 'n', ' ', 't', 'o', 'l', 'l', 'e', 'r', 'a', 'n',
    'c', 'e', ':', '\x00' };

  b_NULL = NULL;
  fileManager(&filestar, &autoflush);
  if (filestar == b_NULL) {
  } else {
    fprintf(filestar, cfmt);
    fflush(filestar);
  }
}

void u_fprintf(double varargin_1)
{
  FILE * b_NULL;
  boolean_T autoflush;
  FILE * filestar;
  static const char cfmt[8] = { '\x0a', '%', '1', '4', '.', '4', 'f', '\x00' };

  b_NULL = NULL;
  fileManager(&filestar, &autoflush);
  if (filestar == b_NULL) {
  } else {
    fprintf(filestar, cfmt, varargin_1);
    fflush(filestar);
  }
}

/* End of code generation (fprintf.c) */
