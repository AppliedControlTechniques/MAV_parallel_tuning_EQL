/*
 * update_parameters_EQL_parallel_avg.c
 *
 * Code generation for function 'update_parameters_EQL_parallel_avg'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "update_parameters_EQL_parallel_avg.h"
#include "fprintf.h"
#include "isequal.h"
#include "mod.h"
#include "update_parameters_EQL_parallel_avg_data.h"
#include <stdio.h>

/* Function Definitions */
void update_parameters_EQL_parallel_avg(const double input[2], double
  main_iteration_counter, const double P1_range[2], const double P2_range[2],
  double Par_initial, double output[5])
{
  double controller_pars_data[4];
  int i0;
  double P_range[4];
  double J;
  double length_old;
  double dv0[2];
  double new_range_idx_0;
  double new_range_idx_1;
  double dv1[2];
  double J_right;

  /*  input                     - values of performance indices (two elements) */
  /*  main_iteration_counter    - iterates from 1 to 56 */
  /*  P1_range                  - admissible range for the first parameter */
  /*  P2_range                  - admissible range for the second parameter */
  /*  Par_initial               - initial value of the second parameter */
  for (i0 = 0; i0 < 4; i0++) {
    controller_pars_data[i0] = 0.0;
  }

  for (i0 = 0; i0 < 2; i0++) {
    P_range[i0 << 1] = P1_range[i0];
    P_range[1 + (i0 << 1)] = P2_range[i0];
  }

  /*  initial range for the 1st parameter (1st row), and the 2nd parameter (2nd row) */
  J = (input[0] + input[1]) / 2.0;

  /*  (matrix in which all data is stored) */
  /*  ID of the changed parameter (== 1 or 2) */
  if (isequal(main_iteration_counter, 0.0)) {
    /*  if the method is launched for the first time */
    b_fprintf();
    c_fprintf();
    d_fprintf();
    e_fprintf();
    f_fprintf();
    g_fprintf();
    h_fprintf();
    b_fprintf();
    i_fprintf();
    j_fprintf();
    k_fprintf();
    l_fprintf();
    m_fprintf();
    n_fprintf();

    /*     fprintf(1,'\n>> Number of FIB iterations to obtain epsilon accuracy = %.6f',N_eql); */
    memset(&information_matrix[0], 0, 399U * sizeof(double));

    /*  generate empty matrix  */
    changed_parameter = 1.0;

    /*  ID of the changed parameter */
    main_iteration_counter = 1.0;

    /*  main counter, defining rows of the information_matrix */
    for (i0 = 0; i0 < 14; i0++) {
      information_matrix[57 + i0] = 1.0;
    }

    /*  change the 1st paramter, fill rows 1-14 */
    information_matrix[0] = 1.0;

    /*  change the 1st paramter */
    length_old = P_range[2] - P_range[0];
    information_matrix[114] = P_range[0];

    /*  calculated value (1st row) */
    information_matrix[171] = P_range[2];

    /*  calculated value (1st row) */
    information_matrix[115] = P_range[0];

    /*  calculated value (1st row) */
    information_matrix[172] = P_range[2];

    /*  calculated value (1st row) */
    information_matrix[228] = P_range[0] + 0.125 * length_old;

    /*  calculated value (1st row) */
    information_matrix[229] = P_range[2] - 0.125 * length_old;

    /*  calculated value (2nd row) */
    for (i0 = 0; i0 < 14; i0++) {
      information_matrix[285 + i0] = Par_initial;
    }

    /*  calculated value, rows 1-14 */
    information_matrix[342] = 0.0;

    /*  value of the performance index */
    information_matrix[343] = 0.0;

    /*  value of the performance index */
    dv0[0] = information_matrix[228];
    dv0[1] = information_matrix[285];
    for (i0 = 0; i0 < 2; i0++) {
      controller_pars_data[i0] = dv0[i0];
    }

    /*  tutaj wystawiono wiersz 1 */
  } else if (isequal(main_iteration_counter, 1.0)) {
    /*  first launch of the method */
    information_matrix[(int)main_iteration_counter + 341] = J;

    /*  r1 */
    information_matrix[(int)main_iteration_counter - 1] = main_iteration_counter;

    /*  r1 */
    o_fprintf(information_matrix[(int)main_iteration_counter - 1]);
    p_fprintf(information_matrix[(int)main_iteration_counter + 56]);
    q_fprintf(information_matrix[(int)main_iteration_counter + 113]);
    r_fprintf(information_matrix[(int)main_iteration_counter + 170]);
    q_fprintf(information_matrix[(int)main_iteration_counter + 227]);
    r_fprintf(information_matrix[(int)main_iteration_counter + 284]);
    q_fprintf(information_matrix[(int)main_iteration_counter + 341]);
    main_iteration_counter++;
    dv0[0] = information_matrix[(int)main_iteration_counter + 227];
    dv0[1] = information_matrix[(int)main_iteration_counter + 284];
    for (i0 = 0; i0 < 2; i0++) {
      controller_pars_data[i0] = dv0[i0];
    }
  } else if (isequal(main_iteration_counter, 2.0)) {
    information_matrix[(int)main_iteration_counter - 1] = main_iteration_counter;
    information_matrix[(int)main_iteration_counter + 341] = J;

    /*  odd row (left-hand side in the range) */
    /*  even row (right-hand side in the range) */
    length_old = P_range[2] - P_range[0];
    if (information_matrix[(int)main_iteration_counter + 340] <=
        information_matrix[(int)main_iteration_counter + 341]) {
      /*  reduce from the right */
      new_range_idx_0 = P_range[0];
      new_range_idx_1 = P_range[2] - 0.125 * length_old;
    } else {
      /*  reduce from the left */
      new_range_idx_0 = P_range[0] + 0.125 * length_old;
      new_range_idx_1 = P_range[2];
    }

    information_matrix[114 + (int)main_iteration_counter] = new_range_idx_0;

    /*  odd row (new range, to-be-reduced) */
    information_matrix[171 + (int)main_iteration_counter] = new_range_idx_1;
    information_matrix[(int)main_iteration_counter + 115] = new_range_idx_0;

    /*  even row (new range, to-be-reduced) */
    information_matrix[(int)main_iteration_counter + 172] = new_range_idx_1;
    information_matrix[228 + (int)main_iteration_counter] = new_range_idx_0 +
      0.125 * length_old;

    /*   */
    information_matrix[(int)main_iteration_counter + 229] = new_range_idx_1 -
      0.125 * length_old;

    /*   */
    dv0[0] = information_matrix[228 + (int)main_iteration_counter];
    dv0[1] = information_matrix[285 + (int)main_iteration_counter];
    for (i0 = 0; i0 < 2; i0++) {
      controller_pars_data[i0] = dv0[i0];
    }

    o_fprintf(information_matrix[(int)main_iteration_counter - 1]);
    p_fprintf(information_matrix[(int)main_iteration_counter + 56]);
    q_fprintf(information_matrix[(int)main_iteration_counter + 113]);
    r_fprintf(information_matrix[(int)main_iteration_counter + 170]);
    q_fprintf(information_matrix[(int)main_iteration_counter + 227]);
    r_fprintf(information_matrix[(int)main_iteration_counter + 284]);
    q_fprintf(information_matrix[(int)main_iteration_counter + 341]);
    main_iteration_counter++;
  } else if (isequal(main_iteration_counter, 56.0)) {
    /*  last call of the algorithm */
    information_matrix[(int)main_iteration_counter + 341] = J;
    information_matrix[(int)main_iteration_counter - 1] = main_iteration_counter;
    o_fprintf(information_matrix[(int)main_iteration_counter - 1]);
    p_fprintf(information_matrix[(int)main_iteration_counter + 56]);
    q_fprintf(information_matrix[(int)main_iteration_counter + 113]);
    r_fprintf(information_matrix[(int)main_iteration_counter + 170]);
    q_fprintf(information_matrix[(int)main_iteration_counter + 227]);
    r_fprintf(information_matrix[(int)main_iteration_counter + 284]);
    q_fprintf(information_matrix[(int)main_iteration_counter + 341]);
    if (information_matrix[396] <= information_matrix[397]) {
      /*  reduce from the right */
      /* disp('The range is reduced from the right to:') */
      new_range_idx_0 = information_matrix[(int)main_iteration_counter + 113];
      new_range_idx_1 = information_matrix[(int)main_iteration_counter + 284];
    } else {
      /*  reduce from the left */
      /* disp('The range is reduced from the left to:') */
      new_range_idx_0 = information_matrix[(int)main_iteration_counter + 283];
      new_range_idx_1 = information_matrix[(int)main_iteration_counter + 170];
    }

    information_matrix[284] = information_matrix[283];
    information_matrix[341] = (new_range_idx_0 + new_range_idx_1) / 2.0;
    n_fprintf();
    dv0[0] = information_matrix[284];
    dv0[1] = information_matrix[341];
    for (i0 = 0; i0 < 2; i0++) {
      controller_pars_data[i0] = dv0[i0];
    }

    s_fprintf();
    t_fprintf();
    u_fprintf(controller_pars_data[0]);
    u_fprintf(controller_pars_data[1]);
    dv1[0] = information_matrix[284];
    dv1[1] = information_matrix[341];
    for (i0 = 0; i0 < 2; i0++) {
      controller_pars_data[i0] = dv1[i0];
    }

    main_iteration_counter = 57.0;
  } else if ((main_iteration_counter >= 3.0) && (main_iteration_counter < 56.0))
  {
    /*  measurements have ended */
    if (isequal(b_mod(main_iteration_counter, 2.0), 1.0)) {
      /*  odd iteration */
      information_matrix[(int)main_iteration_counter + 341] = J;

      /*  r1 */
      information_matrix[(int)main_iteration_counter - 1] =
        main_iteration_counter;

      /*  r1 */
      o_fprintf(information_matrix[(int)main_iteration_counter - 1]);
      p_fprintf(information_matrix[(int)main_iteration_counter + 56]);
      q_fprintf(information_matrix[(int)main_iteration_counter + 113]);
      r_fprintf(information_matrix[(int)main_iteration_counter + 170]);
      q_fprintf(information_matrix[(int)main_iteration_counter + 227]);
      r_fprintf(information_matrix[(int)main_iteration_counter + 284]);
      q_fprintf(information_matrix[(int)main_iteration_counter + 341]);
      main_iteration_counter++;
      dv0[0] = information_matrix[(int)main_iteration_counter + 227];
      dv0[1] = information_matrix[(int)main_iteration_counter + 284];
      for (i0 = 0; i0 < 2; i0++) {
        controller_pars_data[i0] = dv0[i0];
      }
    } else {
      /* if isequal(mod(main_iteration_counter,2),1) % odd iteration */
      information_matrix[(int)main_iteration_counter - 1] =
        main_iteration_counter;

      /*  1) store in information_matrix the current value of J */
      information_matrix[(int)main_iteration_counter + 341] = J;

      /*  2) decide how to reduce the current range */
      J = information_matrix[(int)main_iteration_counter + 340];

      /*  odd row (left-hand side in the range) */
      J_right = information_matrix[(int)main_iteration_counter + 341];

      /*  even row (right-hand side in the range) */
      /*  PROPOSE THE NEW REDUCED RANGE */
      if (isequal(information_matrix[(int)main_iteration_counter + 56], 1.0)) {
        /*  Par 1 */
        length_old = P_range[2] - P_range[0];
      } else {
        length_old = P_range[3] - P_range[1];
      }

      /*  decide how to use it (how to reduce the old range) */
      if (information_matrix[(int)main_iteration_counter + 340] <=
          information_matrix[(int)main_iteration_counter + 341]) {
        /*  reduce from the right */
        /* disp('The range is reduced from the right to:') */
        new_range_idx_0 = information_matrix[(int)main_iteration_counter + 113];
        new_range_idx_1 = information_matrix[(int)main_iteration_counter + 170]
          - 0.125 * length_old;
      } else {
        /*  reduce from the left */
        /* disp('The range is reduced from the left to:') */
        new_range_idx_0 = information_matrix[(int)main_iteration_counter + 113]
          + 0.125 * length_old;
        new_range_idx_1 = information_matrix[(int)main_iteration_counter + 170];
      }

      /*  below: prepare parameters for the next iteration */
      information_matrix[114 + (int)main_iteration_counter] = new_range_idx_0;

      /*  odd row (new range, to-be-reduced) */
      information_matrix[171 + (int)main_iteration_counter] = new_range_idx_1;
      information_matrix[(int)main_iteration_counter + 115] = new_range_idx_0;

      /*  even row (new range, to-be-reduced) */
      information_matrix[(int)main_iteration_counter + 172] = new_range_idx_1;

      /*  3) calculate a pair of values for the next iteration, fill the next two rows */
      /*  current iteration index 1 <= i <= N_eql */
      if (b_mod(main_iteration_counter, 14.0) > 0.0) {
        /*  generate two new points for the selected paramter */
        if (isequal(information_matrix[(int)main_iteration_counter + 56], 1.0))
        {
          /*  Par 1 */
          length_old = P_range[2] - P_range[0];
        } else {
          length_old = P_range[3] - P_range[1];
        }

        if (isequal(b_mod(main_iteration_counter + 2.0, 14.0), 0.0) || isequal
            (b_mod(main_iteration_counter + 2.0, 28.0), 0.0) || isequal(b_mod
             (main_iteration_counter + 2.0, 42.0), 0.0) || isequal(b_mod
             (main_iteration_counter + 2.0, 56.0), 0.0)) {
          /*  two last parameters in every bootstrap need modification (EQL), as in FIB! */
          J_right = new_range_idx_0 + 0.0625 * length_old;
          J = new_range_idx_1 - 0.0625 * length_old;
        } else {
          /*  to dziala OK */
          J_right = new_range_idx_0 + 0.125 * length_old;
          J = new_range_idx_1 - 0.125 * length_old;
        }

        if (isequal(changed_parameter, 1.0)) {
          information_matrix[228 + (int)main_iteration_counter] = J_right;
          information_matrix[(int)main_iteration_counter + 229] = J;

          /*  columnt 6 is filled at the beginning of main */
          /*  iteration with the values of the 2nd paramter */
        } else {
          information_matrix[285 + (int)main_iteration_counter] = J_right;
          information_matrix[(int)main_iteration_counter + 286] = J;

          /*  columnt 5 is filled at the beginning of main */
          /*  iteration with the values of the 1st paramter */
        }
      } else {
        /*  stopping criterion met, prepare the optimal value of the changed_parameter for the next 2*N_eql iterations */
        if (isequal(changed_parameter, 1.0)) {
          if (J <= J_right) {
            /*  reduce from the right */
            new_range_idx_0 = information_matrix[(int)main_iteration_counter +
              112];
            new_range_idx_1 = information_matrix[(int)main_iteration_counter +
              227];
          } else {
            /*  reduce from the left */
            new_range_idx_0 = information_matrix[(int)main_iteration_counter +
              226];
            new_range_idx_1 = information_matrix[(int)main_iteration_counter +
              170];
          }
        } else if (J <= J_right) {
          /*  reduce from the right */
          new_range_idx_0 = information_matrix[(int)main_iteration_counter + 112];
          new_range_idx_1 = information_matrix[(int)main_iteration_counter + 284];
        } else {
          /*  reduce from the left */
          new_range_idx_0 = information_matrix[(int)main_iteration_counter + 283];
          new_range_idx_1 = information_matrix[(int)main_iteration_counter + 170];
        }

        J = (new_range_idx_0 + new_range_idx_1) / 2.0;
        if (isequal(changed_parameter, 1.0)) {
          for (i0 = 0; i0 < 14; i0++) {
            information_matrix[(int)(main_iteration_counter + (1.0 + (double)i0))
              + 227] = J;
          }

          changed_parameter = 2.0;
          for (i0 = 0; i0 < 2; i0++) {
            information_matrix[(int)(main_iteration_counter + (1.0 + (double)i0))
              + 113] = P_range[1];
          }

          for (i0 = 0; i0 < 2; i0++) {
            information_matrix[(int)(main_iteration_counter + (1.0 + (double)i0))
              + 170] = P_range[3];
          }

          /*  generate two new inner solutions */
          length_old = P_range[3] - P_range[1];
          information_matrix[285 + (int)main_iteration_counter] = P_range[1] +
            0.125 * length_old;
          information_matrix[(int)main_iteration_counter + 286] = P_range[3] -
            0.125 * length_old;
        } else {
          for (i0 = 0; i0 < 14; i0++) {
            information_matrix[(int)(main_iteration_counter + (1.0 + (double)i0))
              + 284] = J;
          }

          changed_parameter = 1.0;
          for (i0 = 0; i0 < 2; i0++) {
            information_matrix[(int)(main_iteration_counter + (1.0 + (double)i0))
              + 113] = P_range[0];
          }

          for (i0 = 0; i0 < 2; i0++) {
            information_matrix[(int)(main_iteration_counter + (1.0 + (double)i0))
              + 170] = P_range[2];
          }

          /*  generate two new inner solutions */
          length_old = P_range[3] - P_range[1];
          information_matrix[228 + (int)main_iteration_counter] = P_range[0] +
            0.125 * length_old;
          information_matrix[(int)main_iteration_counter + 229] = P_range[2] -
            0.125 * length_old;
        }

        for (i0 = 0; i0 < 14; i0++) {
          information_matrix[(int)(main_iteration_counter + (1.0 + (double)i0))
            + 56] = changed_parameter;
        }
      }

      o_fprintf(information_matrix[(int)main_iteration_counter - 1]);
      p_fprintf(information_matrix[(int)main_iteration_counter + 56]);
      q_fprintf(information_matrix[(int)main_iteration_counter + 113]);
      r_fprintf(information_matrix[(int)main_iteration_counter + 170]);
      q_fprintf(information_matrix[(int)main_iteration_counter + 227]);
      r_fprintf(information_matrix[(int)main_iteration_counter + 284]);
      q_fprintf(information_matrix[(int)main_iteration_counter + 341]);
      dv0[0] = information_matrix[228 + (int)main_iteration_counter];
      dv0[1] = information_matrix[285 + (int)main_iteration_counter];
      for (i0 = 0; i0 < 2; i0++) {
        controller_pars_data[i0] = dv0[i0];
      }

      main_iteration_counter++;
      if (isequal(b_mod(main_iteration_counter - 1.0, 14.0), 0.0)) {
        n_fprintf();
      }
    }

    /* if isequal(mod(main_iteration_counter,2),1) % odd iteration */
    /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  } else {
    if (isequal(main_iteration_counter, 57.0)) {
      dv0[0] = information_matrix[284];
      dv0[1] = information_matrix[341];
      for (i0 = 0; i0 < 2; i0++) {
        controller_pars_data[i0] = dv0[i0];
      }
    }
  }

  output[0] = controller_pars_data[0];
  output[1] = controller_pars_data[1];
  output[2] = controller_pars_data[0];
  output[3] = controller_pars_data[1];
  output[4] = main_iteration_counter;
}

/* End of code generation (update_parameters_EQL_parallel_avg.c) */
