﻿// THIS FILE IS FOR SLAVE
// THAT CARRIES ALL OPTIMIZATION TASKS

// some ros includes
#include <ros/package.h>
#include <ros/ros.h>

// some std includes
#include <stdio.h>
#include <stdlib.h>

#include <nav_msgs/Odometry.h>
#include <std_msgs/Bool.h>
#include <std_msgs/Float32.h>
#include <std_msgs/Int32.h>
// include messages need to control the flight of the MAV
#include <mrs_msgs/TrackerTrajectory.h>
#include <mrs_msgs/PositionCommand.h>
// include messages for services
#include <std_srvs/Trigger.h>

#include <mutex>
#include <thread>

// this is neccessary to change gains
#include <dynamic_reconfigure/Config.h>
#include <dynamic_reconfigure/Reconfigure.h>
#include <dynamic_reconfigure/ReconfigureRequest.h>

#include "update_parameters_EQL_parallel_avg.h"

#define SLEEP_DURATION 200
#define PUBLISH_REPETITION 5

// subscribers
ros::Subscriber sub_start_next_iteration;
ros::Subscriber sub_UAV2_gain1;
ros::Subscriber sub_UAV2_gain2;
// publishers
ros::Publisher pub_UAV2_gains_changed;
ros::Publisher pub_next_iteration_started;
ros::Publisher pub_UAV2_perf_collected;
// data from outside
bool               got_error          = false;
bool               uav2_gains_changed = false;
// parameters from config files
int    main_loop_rate;
int    thread_rate;
int    loop_count;

////////////////////////////////////////////////////////////////////////


double use_filtered = 1;

double prior_filtered_control_error = 0;    // used when filtered error is passed to the function
double prior_control_error          = 0.1;  // used as above, initially non-zero to obtain non-zero filt'd error
double aux_variable;
double main_iteration_counter = 0;

double output_EQL_parallel[5];

double Par_initial = 0.2;  // TODO: the value should be set
// states of the state machine
typedef enum {
  IDLE     = 0,  // keeping constant altitude, fixed gains
  FLYING   = 1,  // change gains, and after that gather performance index
  OPTIMIZE = 2,  // perform single optimization step, afterwards - move to FLYING state
} state_gains;

double P1_range[2];
double P2_range[2];

double J_UAV[2];  //[2];

// J_UAV[0] = 0;
// J_UAV[1] = 0;

bool UAV2_perf_collected    = false;  // informs if UAV2 collected perf index successfully
bool uav2_gain1_set         = false;
bool uav2_gain2_set         = false;
bool start_next_iteration   = false;
bool next_iteration_started = false;

double UAV2_gain1;
double UAV2_gain2;

double UAV2_perf;  // performance index obtained from UAV2
double start_x, start_y;


double UAV_tuning_finished;  // informs if tuning has finished

// UAV_tuning_finished = 0; // initially logical zero

state_gains current_state = IDLE;
state_gains past_state    = IDLE;
double      control_error;

// just count how many times the thread has looped
int looped = 0;

// the trajectory primitive
std::vector<double> trajectory_primitive_x;
std::vector<double> trajectory_primitive_y;
std::vector<double> trajectory_primitive_z;

// variable that hold the default gains
Gains_t            default_gains;
Gains_t            modified_gains_UAV2;
ros::ServiceClient set_gains_client;

void init_variables() {
  J_UAV[0]            = 0;
  J_UAV[1]            = 0;
  P1_range[0]         = 0;
  P1_range[1]         = 1;
  P2_range[0]         = 0;
  P2_range[1]         = 1;
  UAV2_perf_collected = false;
  UAV2_perf           = 0;
  UAV_tuning_finished = 0;  // initially logical zero
}


void publishGainsChanged() {
  std_msgs::Bool msg;
  msg.data = uav2_gains_changed;
  pub_UAV2_gains_changed.publish(msg);
}

void publishUAV2PerfCollected() {
  std_msgs::Float32 msg;
  msg.data = UAV2_perf;
  pub_UAV2_perf_collected.publish(msg);
  ROS_INFO("UAV2performance published");
}

void startNextIterationCallback(const std_msgs::Bool& msg) {
  start_next_iteration = msg.data;
}


void uav2Gain1Callback(const std_msgs::Float32& msg) {
  UAV2_gain1     = msg.data;
  uav2_gain1_set = true;
}


void uav2Gain2Callback(const std_msgs::Float32& msg) {
  UAV2_gain2     = msg.data;
  uav2_gain2_set = true;
}


// method for changing state
void changeState(state_gains new_state) {

  past_state    = current_state;
  current_state = new_state;

  // make actions when changing to some states
  switch (new_state) {

    case IDLE:
      // do nothing, simply hover

      ROS_INFO("Changing to IDLE state");

      break;

    case FLYING:
      {
      // publish trajectory and gather performance index

      looped = 0;
      ROS_WARN("Changing to FLYING state");
      ROS_WARN("Publishing trajectory!!!");
      uav2_gains_changed       = false;
      modified_gains_UAV2.kp_z = UAV2_gain1;
      modified_gains_UAV2.kd_z = UAV2_gain2;
      setGains(modified_gains_UAV2);
      ros::Duration wait(1.0);
      wait.sleep();
      publishPrimitiveTrajectory();
      uav2_gain1_set = false;
      uav2_gain2_set = false;
      }
      break;
  }
}

bool startServiceCallback(std_srvs::Trigger::Request& req, std_srvs::Trigger::Response& res) {

  start_x = setpoint_.position.x;
  start_y = setpoint_.position.y;
  std_msgs::Float32 float_message;

  J_UAV[0] = 0;  // dummy - first call of the method does not require that, it only modifies gains!
  J_UAV[1] = 0;  // dummy - first call of the method does not require that, it only modifies gains!

  changeState(FLYING);
  res.success = true;
  res.message = "Switching to FLYING state -- main callback call";

  if (use_filtered) {
    ROS_INFO("The metod will use the low-pass filtered error signal");
  }
  return true;
}

void mainThread(void) {

  ros::Rate r(thread_rate);

  // infinitely run a state machine
  while (ros::ok()) {

    // this makes the thread run with the set rate
    r.sleep();

    if (!got_odometry || !got_setpoint || !got_error) {

      ROS_WARN_THROTTLE(1, "Missing some data...");
      continue;
    }

    ROS_INFO_ONCE("The thread has started...");

    std_msgs::Float32 float_message;

    switch (current_state) {

      case IDLE:
        // IDLE: drone hovers
        // drone awaits for flags indicating successfull collection of performance indices
        if (uav2_gain1_set && uav2_gain2_set) {
          ROS_INFO("Gains set.");
          uav2_gains_changed = true;
          publishGainsChanged();
          UAV2_perf = 0;
        }

        if (start_next_iteration && uav2_gains_changed) {
          changeState(FLYING);
          next_iteration_started = true;
          for (int i = 0; i < PUBLISH_REPETITION; i++) {
            publishNextIterationStarted();
          }
          next_iteration_started = false;
        }
        break;

      case FLYING:
        {
        // FLYING: drone track a single reference primitive
        // drone awaits for flags indicating successfull collection of performance indices

        UAV2_perf_collected = false;
        publishUAV2PerfCollected();
        // increment performance index of UAV1 (absolute value of tracking error)
        UAV2_perf += fabs(control_error);
        // increment the loop counter
        looped++;

        if ((unsigned long)looped == loop_count * trajectory_primitive_z.size()) {
          // if the reference primitive is finished, jump to idle state
          // to wait for UAV2 to return its performance indices

          ROS_WARN("Performance index has been collected (by UAV1)");
          UAV2_perf_collected = true;  // UAV1 has collected its performance index
          for (int i = 0; i < PUBLISH_REPETITION; i++) {
            publishUAV2PerfCollected();
          }
          UAV2_perf_collected = false;
          ROS_WARN("Performance index has been collected (by UAV2)");
          changeState(IDLE);
        }  // go back to FLYING state to get new performance indices

        }
        break;
    }
  }
}

  // allowable range for parameter no. 1
  nh.param("P1_range_low", P1_range[0], 0.0);
  nh.param("P1_range_high", P1_range[1], 1.0);
  // allowable range for parameter no. 2
  nh.param("P2_range_low", P2_range[0], 0.0);
  nh.param("P2_range_high", P2_range[1], 1.0);

  output_EQL_parallel[0] = 0;
  output_EQL_parallel[1] = 0;
  output_EQL_parallel[2] = 0;
  output_EQL_parallel[3] = 0;
  output_EQL_parallel[4] = 0;

